#include <gbdk/platform.h>

void main(void) {
    DISPLAY_ON;
    while(TRUE) {
        vsync();
    }
}
