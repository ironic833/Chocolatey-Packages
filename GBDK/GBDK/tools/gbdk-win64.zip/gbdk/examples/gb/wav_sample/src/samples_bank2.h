#ifndef SAMPLES_BANK2_H_INCLUDE
#define SAMPLES_BANK2_H_INCLUDE

void play_sample1(void) __banked;

#endif