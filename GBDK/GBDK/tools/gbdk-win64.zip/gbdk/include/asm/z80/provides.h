#define USE_C_MEMCPY	0
#define USE_C_STRCPY	0
#define USE_C_STRCMP	1

